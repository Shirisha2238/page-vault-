# Source notes

- The hackathon brief (`view.pdf`) is the functional specification used for this full-stack build.
- The uploaded `index.html` is a standalone directory of free digital-library links, rather than a peer-to-peer textbook exchange UI. This package therefore follows the hackathon's OpenShelf exchange requirements and uses the PageVault name/identity, rather than carrying over that unrelated source-list interface.
