const $ = s => document.querySelector(s);
let userId = 1, users = [], books = [], toastTimer;
const headers = () => ({ "Content-Type":"application/json", "x-user-id":String(userId) });
async function api(url, options={}) {
  const res=await fetch(url,{...options,headers:{...headers(),...(options.headers||{})}});
  const data=await res.json().catch(()=>({}));
  if(!res.ok) throw new Error(data.error||"Something went wrong.");
  return data;
}
function toast(msg){const el=$("#toast");el.textContent=msg;el.classList.add("show");clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove("show"),2600);}
function esc(s=""){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function dateShort(d){return d?new Date(d).toLocaleDateString(undefined,{day:"numeric",month:"short",year:"numeric"}):"—";}
async function init(){
  users=await api("/api/users");
  $("#userSelect").innerHTML=users.map(u=>`<option value="${u.id}">${esc(u.name)} · ${esc(u.department)}</option>`).join("");
  $("#userSelect").value=userId;
  await refreshAll();
}
async function refreshAll(){await Promise.all([loadBooks(),loadDashboard(),loadReminders()]);}
async function loadBooks(){
  const p=new URLSearchParams({q:$("#search").value,status:$("#statusFilter").value,department:$("#deptFilter").value});
  books=await api("/api/books?"+p.toString());
  const depts=[...new Set((await api("/api/books")).map(b=>b.department))].sort();
  const old=$("#deptFilter").value;
  $("#deptFilter").innerHTML='<option value="">All departments</option>'+depts.map(d=>`<option>${esc(d)}</option>`).join("");
  $("#deptFilter").value=old;
  $("#resultCount").textContent=`${books.length} textbook${books.length===1?"":"s"} found`;
  $("#bookGrid").innerHTML=books.length?books.map(b=>`<article class="book-card"><div class="card-top"><span class="course">${esc(b.course_code)}</span><span class="status ${b.status}">${b.status}</span></div><h3>${esc(b.title)}</h3><p class="meta">by ${esc(b.author)} · ${esc(b.edition)}</p><p class="meta">${esc(b.department)} · ${esc(b.condition)} condition</p><div class="card-bottom"><span class="owner">Listed by ${esc(b.owner_name)}</span><button class="small-btn" data-request="${b.id}" ${b.status!=="Available"||b.owner_id===userId?"disabled":""}>Request borrow</button></div></article>`).join(""):'<div class="empty">No books match your search. Try another course code or search term.</div>';
}
async function loadDashboard(){
  const d=await api("/api/dashboard");
  $("#stats").innerHTML=`<div class="stat"><strong>${d.stats.listed}</strong><span>Books listed</span></div><div class="stat"><strong>${d.stats.borrowed}</strong><span>Currently borrowed</span></div><div class="stat"><strong>${d.stats.pending}</strong><span>Requests to review</span></div>`;
  $("#myBooks").innerHTML=d.listed.length?d.listed.map(b=>`<div class="dash-item"><strong>${esc(b.title)}</strong><p>${esc(b.course_code)} · ${b.status}</p><div class="actions">${b.status==="Available"?`<button class="small-btn" data-availability="${b.id}" data-value="0">Pause listing</button>`:""}${b.status==="Reserved"?'<span class="meta">A request is awaiting your response</span>':""}</div></div>`).join(""):'<div class="empty">You have not listed a book yet.</div>';
  $("#myRequests").innerHTML=d.requests.length?d.requests.map(r=>{
    const isLender=r.lender_id===userId, other=isLender?r.borrower_name:r.lender_name;
    const due=r.due_date?` · Due ${dateShort(r.due_date)}`:"";
    let actions="";
    if(isLender&&r.status==="Pending")actions=`<button class="small-btn" data-action="approve" data-id="${r.id}">Approve</button><button class="small-btn" data-action="reject" data-id="${r.id}">Decline</button>`;
    if(r.status==="Approved")actions=`<button class="small-btn" data-action="return" data-id="${r.id}">Mark returned</button>`;
    const countdown=r.status==="Approved"&&r.due_date?`<p class="${new Date(r.due_date)<new Date()?"form-error":""}">Return ${new Date(r.due_date)<new Date()?"overdue":`in ${Math.max(0,Math.ceil((new Date(r.due_date)-Date.now())/86400000))} day(s)`}</p>`:"";
    return `<div class="dash-item"><strong>${esc(r.book_title)}</strong><p>${isLender?"Borrow request from":"Borrowing from"} ${esc(other)} · ${r.status}${due}</p>${countdown}<div class="actions">${actions}</div></div>`;
  }).join(""):'<div class="empty">No borrowing activity yet. Request a book from the catalog to get started.</div>';
}
async function loadReminders(){
  const d=await api("/api/notifications");
  const items=d.reminders||[];
  $("#reminderArea").innerHTML=items.map(r=>`<div class="reminder ${r.days_left<0?"overdue":""}">${r.days_left<0?"Overdue return:":r.days_left===0?"Due today:":"Coming up:"} <strong>${esc(r.book_title)}</strong> — ${r.days_left<0?`${Math.abs(r.days_left)} day(s) overdue`:r.days_left===0?"return today":`due in ${r.days_left} day(s)`} (${dateShort(r.due_date)}). Please coordinate the return with your lender.</div>`).join("");
  if(items.length && "Notification" in window && Notification.permission==="granted") {
    const first=items[0]; new Notification("PageVault return reminder",{body:`${first.book_title}: ${first.days_left<0?"overdue":`due in ${first.days_left} day(s)`}.`});
  }
}
$("#search").addEventListener("input",loadBooks);
$("#statusFilter").addEventListener("change",loadBooks);
$("#deptFilter").addEventListener("change",loadBooks);
$("#userSelect").addEventListener("change",async e=>{userId=Number(e.target.value);await refreshAll();toast("Demo user changed.");});
$("#refresh").addEventListener("click",refreshAll);
$("#openList").addEventListener("click",()=>$("#listDialog").showModal());
$("#closeList").addEventListener("click",()=>$("#listDialog").close());
$("#listForm").addEventListener("submit",async e=>{
  e.preventDefault();const data=Object.fromEntries(new FormData(e.target).entries());
  try{await api("/api/books",{method:"POST",body:JSON.stringify(data)});e.target.reset();$("#listDialog").close();await refreshAll();toast("Your book is now listed.");}
  catch(err){$("#formError").textContent=err.message;}
});
document.addEventListener("click",async e=>{
  const req=e.target.closest("[data-request]");
  const action=e.target.closest("[data-action]");
  const availability=e.target.closest("[data-availability]");
  try{
    if(req){await api("/api/requests",{method:"POST",body:JSON.stringify({book_id:Number(req.dataset.request)})});toast("Borrow request sent to the lender.");await refreshAll();}
    if(action){await api(`/api/requests/${action.dataset.id}`,{method:"PATCH",body:JSON.stringify({action:action.dataset.action})});toast(`Request ${action.dataset.action==="approve"?"approved":action.dataset.action==="reject"?"declined":"marked returned"}.`);await refreshAll();}
    if(availability){await api(`/api/books/${availability.dataset.availability}/availability`,{method:"PATCH",body:JSON.stringify({available:Boolean(Number(availability.dataset.value))})});await refreshAll();toast("Listing availability updated.");}
  }catch(err){toast(err.message);}
});
if("Notification" in window && Notification.permission==="default") {
  // Permission is requested only after a user gesture.
  document.addEventListener("click",()=>Notification.requestPermission(),{once:true});
}
init().catch(e=>{console.error(e);toast("Could not connect to the PageVault server.");});