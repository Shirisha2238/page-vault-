# PageVault — OpenShelf Challenge

A full-stack campus peer-to-peer textbook exchange application. Students can list textbooks, search by title/author/course code/department, request borrowings, approve requests, track 7-day due dates and mark returns.

## Features

### Core requirements
- Book listings with title, author, edition, course code, department, condition and availability.
- Live catalog filtering by title, author, course code, department and availability.
- Three main exchange states: **Pending → Approved → Returned** (a lender can also decline a pending request).
- Availability badges: Available, Reserved and Borrowed.
- Seven-day due-date calculation, countdowns, overdue banners and browser notification reminders.
- Dashboard for listed books, incoming requests, current borrowings and exchange history.
- SQLite database with Users, Books, Borrow Requests, Reviews and Notifications tables.
- 35 seeded sample textbooks across engineering and science departments.

### Additional implementation
- Demo user switcher to test lender and borrower journeys without a sign-up flow.
- Atomic request creation using a SQLite transaction to prevent two students requesting the same available book simultaneously.
- Basic 1–5 star review API for exchange participants after a book is returned.
- Responsive interface for desktop and mobile.

## Requirements

- Node.js 18 or newer
- npm

## Run locally

```bash
# 1. Extract the ZIP and open the project folder
cd pagevault-fullstack

# 2. Install dependencies
npm install

# 3. Create the SQLite database and sample data
npm run seed

# 4. Start the server
npm start
```

Open **http://localhost:3000** in your browser.

For development with automatic server restart:

```bash
npm run dev
```

The SQLite database is created at `data/pagevault.db` the first time the app runs. The `data/` directory is created automatically. Run `npm run seed` to insert the demo users and 35 sample books into an empty database.

## Demo walkthrough

1. Open the app. The demo user selector starts as **Aarav Sharma**.
2. Find **Operating System Concepts** (course code `CS301`) and note its lender.
3. Switch to a different demo user, such as **Diya Reddy**, and request the book.
4. Switch back to the lender account (Aarav Sharma) and open **My exchanges**.
5. Approve the pending request. The book becomes **Borrowed**, and the borrower receives a seven-day due date.
6. Switch to the borrower account. The countdown and reminder appear in the dashboard/reminder area.
7. Mark the exchange as returned from either participant's dashboard. The book becomes available again.

> The demo user switcher is intentionally a lightweight presentation/testing mechanism. It is not production authentication. Do not deploy this demo publicly with real student data without adding secure authentication and authorization.

## API reference

All endpoints are prefixed with `/api`. The current demo user is selected with the `x-user-id` request header (defaults to user `1`).

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/health` | Server health check |
| GET | `/api/users` | List demo users |
| GET | `/api/books` | Search/filter catalog |
| POST | `/api/books` | Create a book listing |
| PATCH | `/api/books/:id/availability` | Pause/resume a listing |
| POST | `/api/requests` | Create a borrow request |
| GET | `/api/requests` | List requests involving current user |
| PATCH | `/api/requests/:id` | Approve, reject or mark returned |
| GET | `/api/dashboard` | Current user's books, requests and stats |
| GET | `/api/notifications` | Notifications and due reminders |
| POST | `/api/reviews` | Submit a 1–5 rating after return |

### Example requests

```bash
# Browse the CS301 catalog
curl "http://localhost:3000/api/books?q=CS301"

# List books for demo user 1
curl -H "x-user-id: 1" "http://localhost:3000/api/dashboard"

# Create a listing
curl -X POST http://localhost:3000/api/books \
  -H "Content-Type: application/json" -H "x-user-id: 1" \
  -d '{"title":"Computer Networks","author":"A. Tanenbaum","edition":"6th","course_code":"CS302","department":"Computer Science","condition":"Good"}'

# Request book 1 as demo user 2
curl -X POST http://localhost:3000/api/requests \
  -H "Content-Type: application/json" -H "x-user-id: 2" \
  -d '{"book_id":1}'

# Approve request 1 as its lender (demo user 1)
curl -X PATCH http://localhost:3000/api/requests/1 \
  -H "Content-Type: application/json" -H "x-user-id: 1" \
  -d '{"action":"approve"}'
```

### Search query parameters

`GET /api/books` accepts:
- `q`: matches title, author, course code or department.
- `course`: matches part of a course code.
- `department`: exact department filter.
- `status`: Available, Reserved or Borrowed.

## Project structure

```text
pagevault-fullstack/
├── public/
│   ├── index.html       # Frontend page
│   ├── styles.css       # Responsive styling
│   └── app.js           # Browser logic and API calls
├── src/
│   ├── db.js            # SQLite schema and connection
│   ├── seed.js          # Demo users and 35 sample books
│   └── server.js        # Express REST API
├── data/                # SQLite database is created here
├── package.json
├── .gitignore
└── README.md
```

## Notes and limitations

- Browser reminders are simulated when the app is open; they are not guaranteed background push notifications when the browser is closed. The server calculates due status from stored due dates when `/api/notifications` is requested.
- The optional ISBN camera scanner, live chat, and wishlist alert UI are not included in this first full-stack build. The challenge lists these as stretch features, not must-have features.
- The review submission endpoint is implemented; a review form/UI can be added as a next enhancement.
- The Open Library API is not required for the core exchange workflow and is not wired into this build.
- For production: add password-based or campus SSO authentication, session/JWT security, rate limiting, validation, CSRF protection as appropriate, audit logs, and a scheduled notification service.

## Troubleshooting

- **`npm` is not recognized:** install Node.js LTS, reopen the terminal, and check `node -v` and `npm -v`.
- **Port 3000 is busy:** on Windows PowerShell run `$env:PORT=3001; npm start`; on macOS/Linux run `PORT=3001 npm start`.
- **Database needs a fresh demo reset:** stop the server, delete `data/pagevault.db` and its `-shm`/`-wal` files if present, then run `npm run seed` again.
