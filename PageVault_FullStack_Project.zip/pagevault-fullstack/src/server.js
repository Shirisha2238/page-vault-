const express = require("express");
const cors = require("cors");
const path = require("path");
const db = require("./db");
const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, "..", "public")));

const currentUser = req => Number(req.header("x-user-id") || 1);
const bookSelect = `
SELECT b.*, u.name AS owner_name,
 (SELECT ROUND(AVG(r.rating),1) FROM reviews r WHERE r.reviewee_id=b.owner_id) AS owner_rating
FROM books b JOIN users u ON u.id=b.owner_id`;

app.get("/api/health", (req,res) => res.json({status:"ok", app:"PageVault"}));
app.get("/api/users", (req,res) => res.json(db.prepare("SELECT id,name,email,department FROM users ORDER BY id").all()));

app.get("/api/books", (req,res) => {
  const { q="", status="", department="", course="" } = req.query;
  let sql = bookSelect + " WHERE 1=1";
  const args = [];
  if (q) { sql += " AND (b.title LIKE ? OR b.author LIKE ? OR b.course_code LIKE ? OR b.department LIKE ?)"; const x=`%${q}%`; args.push(x,x,x,x); }
  if (status) { sql += " AND b.status=?"; args.push(status); }
  if (department) { sql += " AND b.department=?"; args.push(department); }
  if (course) { sql += " AND b.course_code LIKE ?"; args.push(`%${course}%`); }
  sql += " ORDER BY b.created_at DESC, b.id DESC";
  res.json(db.prepare(sql).all(...args));
});

app.post("/api/books", (req,res) => {
  const {title,author,edition,course_code,department,condition,isbn,description} = req.body;
  if (![title,author,course_code,department,condition].every(v => String(v||"").trim())) return res.status(400).json({error:"Please complete all required book details."});
  if (!["New","Like New","Good","Acceptable"].includes(condition)) return res.status(400).json({error:"Invalid book condition."});
  const info = db.prepare(`INSERT INTO books(owner_id,title,author,edition,course_code,department,condition,isbn,description)
    VALUES(?,?,?,?,?,?,?,?,?)`).run(currentUser(req),title.trim(),author.trim(),edition||"1st",course_code.trim().toUpperCase(),department,condition,isbn||"",description||"");
  res.status(201).json(db.prepare(bookSelect+" WHERE b.id=?").get(info.lastInsertRowid));
});

app.patch("/api/books/:id/availability", (req,res) => {
  const book = db.prepare("SELECT * FROM books WHERE id=?").get(req.params.id);
  if (!book) return res.status(404).json({error:"Book not found."});
  if (book.owner_id !== currentUser(req)) return res.status(403).json({error:"Only the lender can change availability."});
  if (book.status !== "Available" && req.body.available) return res.status(409).json({error:"An active exchange is in progress."});
  db.prepare("UPDATE books SET available=?, status=? WHERE id=?").run(req.body.available?1:0,req.body.available?"Available":"Reserved",book.id);
  res.json({success:true});
});

app.post("/api/requests", (req,res) => {
  const bookId = Number(req.body.book_id), borrowerId = currentUser(req);
  const create = db.transaction(() => {
    const book = db.prepare("SELECT * FROM books WHERE id=?").get(bookId);
    if (!book) throw new Error("BOOK_NOT_FOUND");
    if (book.owner_id === borrowerId) throw new Error("OWN_BOOK");
    if (!book.available || book.status !== "Available") throw new Error("NOT_AVAILABLE");
    const active = db.prepare("SELECT id FROM borrow_requests WHERE book_id=? AND status IN ('Pending','Approved')").get(bookId);
    if (active) throw new Error("ALREADY_REQUESTED");
    const info = db.prepare("INSERT INTO borrow_requests(book_id,borrower_id,lender_id) VALUES(?,?,?)").run(bookId,borrowerId,book.owner_id);
    db.prepare("UPDATE books SET status='Reserved' WHERE id=?").run(bookId);
    db.prepare("INSERT INTO notifications(user_id,message,kind) VALUES(?,?,?)").run(book.owner_id,`A student requested "${book.title}". Review it in My Exchanges.`,"request");
    return info.lastInsertRowid;
  });
  try { const id=create(); res.status(201).json(db.prepare(requestSelect+" WHERE br.id=?").get(id)); }
  catch(e) { const map={BOOK_NOT_FOUND:[404,"Book not found."],OWN_BOOK:[400,"You cannot request your own book."],NOT_AVAILABLE:[409,"This book is no longer available."],ALREADY_REQUESTED:[409,"This book already has an active request."]}; const m=map[e.message]||[500,"Could not create request."]; res.status(m[0]).json({error:m[1]}); }
});

const requestSelect = `
SELECT br.*, b.title AS book_title, b.course_code, b.owner_id,
 lender.name AS lender_name, borrower.name AS borrower_name
FROM borrow_requests br JOIN books b ON b.id=br.book_id
JOIN users lender ON lender.id=br.lender_id JOIN users borrower ON borrower.id=br.borrower_id`;

app.get("/api/requests", (req,res) => {
  const uid=currentUser(req);
  res.json(db.prepare(requestSelect+" WHERE br.borrower_id=? OR br.lender_id=? ORDER BY br.requested_at DESC").all(uid,uid));
});

app.patch("/api/requests/:id", (req,res) => {
  const {action}=req.body, uid=currentUser(req), id=Number(req.params.id);
  const tx=db.transaction(() => {
    const r=db.prepare("SELECT * FROM borrow_requests WHERE id=?").get(id);
    if(!r) throw new Error("NOT_FOUND");
    if(action==="approve") {
      if(r.lender_id!==uid || r.status!=="Pending") throw new Error("NOT_ALLOWED");
      const book=db.prepare("SELECT * FROM books WHERE id=?").get(r.book_id);
      if(book.status!=="Reserved") throw new Error("NO_LONGER_AVAILABLE");
      const due=new Date(Date.now()+7*24*60*60*1000).toISOString();
      db.prepare("UPDATE borrow_requests SET status='Approved',approved_at=CURRENT_TIMESTAMP,due_date=? WHERE id=?").run(due,id);
      db.prepare("UPDATE books SET status='Borrowed',available=0 WHERE id=?").run(r.book_id);
      db.prepare("INSERT INTO notifications(user_id,message,kind) VALUES(?,?,?)").run(r.borrower_id,`Your request for "${book.title}" was approved. Return it by ${due.slice(0,10)}.`,"approved");
    } else if(action==="reject") {
      if(r.lender_id!==uid || r.status!=="Pending") throw new Error("NOT_ALLOWED");
      db.prepare("UPDATE borrow_requests SET status='Rejected' WHERE id=?").run(id);
      db.prepare("UPDATE books SET status='Available',available=1 WHERE id=?").run(r.book_id);
    } else if(action==="return") {
      if(r.lender_id!==uid && r.borrower_id!==uid) throw new Error("NOT_ALLOWED");
      if(r.status!=="Approved") throw new Error("NOT_ACTIVE");
      db.prepare("UPDATE borrow_requests SET status='Returned',returned_at=CURRENT_TIMESTAMP WHERE id=?").run(id);
      db.prepare("UPDATE books SET status='Available',available=1 WHERE id=?").run(r.book_id);
    } else throw new Error("BAD_ACTION");
  });
  try { tx(); res.json(db.prepare(requestSelect+" WHERE br.id=?").get(id)); }
  catch(e) { const map={NOT_FOUND:[404,"Request not found."],NOT_ALLOWED:[403,"You are not allowed to do that."],NO_LONGER_AVAILABLE:[409,"This book is no longer available."],NOT_ACTIVE:[409,"This request is not active."],BAD_ACTION:[400,"Unknown action."]}; const m=map[e.message]||[500,"Could not update request."]; res.status(m[0]).json({error:m[1]}); }
});

app.get("/api/dashboard", (req,res) => {
  const uid=currentUser(req);
  const listed=db.prepare(bookSelect+" WHERE b.owner_id=? ORDER BY b.created_at DESC").all(uid);
  const requests=db.prepare(requestSelect+" WHERE br.borrower_id=? OR br.lender_id=? ORDER BY br.requested_at DESC").all(uid,uid);
  const borrowed=requests.filter(r=>r.borrower_id===uid && r.status==="Approved");
  res.json({listed,requests,borrowed,stats:{listed:listed.length,borrowed:borrowed.length,pending:requests.filter(r=>r.lender_id===uid&&r.status==="Pending").length}});
});

app.get("/api/notifications", (req,res) => {
  const uid=currentUser(req);
  const notes=db.prepare("SELECT * FROM notifications WHERE user_id=? ORDER BY created_at DESC LIMIT 30").all(uid);
  const requests=db.prepare(requestSelect+" WHERE br.borrower_id=? AND br.status='Approved'").all(uid);
  const now=Date.now();
  const reminders=requests.filter(r=>r.due_date).map(r=>({...r,days_left:Math.ceil((new Date(r.due_date)-now)/86400000)}))
    .filter(r=>r.days_left<=2);
  res.json({notifications:notes,reminders});
});

app.post("/api/reviews", (req,res) => {
  const uid=currentUser(req), {request_id,rating,comment=""}=req.body;
  const r=db.prepare("SELECT * FROM borrow_requests WHERE id=? AND status='Returned'").get(request_id);
  if(!r || (r.borrower_id!==uid && r.lender_id!==uid)) return res.status(400).json({error:"Reviews are available to exchange participants after return."});
  const reviewee=r.borrower_id===uid?r.lender_id:r.borrower_id;
  try {
    db.prepare("INSERT INTO reviews(request_id,reviewer_id,reviewee_id,rating,comment) VALUES(?,?,?,?,?)").run(request_id,uid,reviewee,Number(rating),comment);
    res.status(201).json({success:true});
  } catch(e) { res.status(400).json({error:"You may have already reviewed this exchange, or the rating is invalid."}); }
});

app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"..","public","index.html")));
app.listen(PORT,()=>console.log(`PageVault running at http://localhost:${PORT}`));