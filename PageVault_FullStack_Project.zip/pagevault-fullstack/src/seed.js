const db = require("./db");

const users = [
  ["Aarav Sharma", "aarav@campus.edu", "Computer Science"],
  ["Diya Reddy", "diya@campus.edu", "Electronics"],
  ["Kabir Rao", "kabir@campus.edu", "Mechanical"],
  ["Meera Iyer", "meera@campus.edu", "Data Science"],
  ["Ishaan Gupta", "ishaan@campus.edu", "Electrical"]
];
const insertUser = db.prepare("INSERT OR IGNORE INTO users(name,email,department) VALUES(?,?,?)");
users.forEach(u => insertUser.run(...u));

const count = db.prepare("SELECT COUNT(*) AS n FROM books").get().n;
if (count === 0) {
  const books = [
    ["Operating System Concepts","Abraham Silberschatz","10th","CS301","Computer Science","Good","9781119800361"],
    ["Computer Networking: A Top-Down Approach","James Kurose","8th","CS302","Computer Science","Like New","9780136681557"],
    ["Database System Concepts","Abraham Silberschatz","7th","CS303","Computer Science","Good","9780078022159"],
    ["Introduction to Algorithms","Thomas H. Cormen","4th","CS304","Computer Science","Acceptable","9780262046305"],
    ["Computer Organization and Design","David A. Patterson","6th","CS305","Computer Science","Like New","9780128201091"],
    ["Clean Code","Robert C. Martin","1st","CS306","Computer Science","Good","9780132350884"],
    ["The C Programming Language","Brian W. Kernighan","2nd","CS101","Computer Science","Good","9780131103627"],
    ["Python Crash Course","Eric Matthes","3rd","CS102","Computer Science","New","9781718502703"],
    ["Java: The Complete Reference","Herbert Schildt","12th","CS201","Computer Science","Good","978126 resume"],
    ["Artificial Intelligence: A Modern Approach","Stuart Russell","4th","AI301","Artificial Intelligence","Like New","9780134610993"],
    ["Data Science from Scratch","Joel Grus","2nd","DS201","Data Science","Good","9781492041139"],
    ["Hands-On Machine Learning","Aurélien Géron","3rd","DS302","Data Science","Like New","9781098125974"],
    ["Pattern Recognition and Machine Learning","Christopher Bishop","1st","DS303","Data Science","Acceptable","9780387310732"],
    ["Introduction to Linear Algebra","Gilbert Strang","6th","MA201","Mathematics","Good","9780980232776"],
    ["Engineering Mathematics","B. S. Grewal","44th","MA101","Mathematics","Good","9788193328491"],
    ["Higher Engineering Mathematics","B. V. Ramana","1st","MA102","Mathematics","Acceptable","9780070634190"],
    ["Fundamentals of Electric Circuits","Charles Alexander","7th","EE201","Electrical","Good","9781260226409"],
    ["Electrical Machinery","P. S. Bimbhra","7th","EE302","Electrical","Like New","978812192ಾರ"],
    ["Power System Engineering","D. P. Kothari","3rd","EE303","Electrical","Good","9780070494893"],
    ["Microelectronic Circuits","Adel Sedra","8th","EC201","Electronics","Good","9780190853464"],
    ["Digital Design","M. Morris Mano","6th","EC202","Electronics","Like New","9780134549897"],
    ["Signals and Systems","Alan V. Oppenheim","2nd","EC301","Electronics","Acceptable","9780138147570"],
    ["Electronic Devices and Circuit Theory","Robert Boylestad","11th","EC203","Electronics","Good","9780132622264"],
    ["Engineering Mechanics: Statics","R. C. Hibbeler","15th","ME201","Mechanical","Good","9780133918922"],
    ["Thermodynamics: An Engineering Approach","Yunus Cengel","9th","ME202","Mechanical","Like New","9781259822674"],
    ["Fluid Mechanics","Frank White","9th","ME301","Mechanical","Good","9781260575547"],
    ["Manufacturing Engineering and Technology","Serope Kalpakjian","8th","ME302","Mechanical","Acceptable","9780135228463"],
    ["Strength of Materials","R. K. Bansal","6th","CE201","Civil","Good","9788131808153"],
    ["Surveying Vol. 1","B. C. Punmia","17th","CE202","Civil","Good","978817 incorporate"],
    ["Structural Analysis","R. C. Hibbeler","10th","CE301","Civil","Like New","9780134610672"],
    ["Engineering Chemistry","Jain and Jain","17th","CH101","Chemistry","Good","9788121922089"],
    ["Engineering Physics","Gaur and Gupta","1st","PH101","Physics","Acceptable","9788189928211"],
    ["Environmental Science","Benny Joseph","3rd","EVS101","Environmental Science","Good","9780070264627"],
    ["Professional Communication","Meenakshi Raman","3rd","HS101","Humanities","Like New","9780199457060"],
    ["The Design of Everyday Things","Don Norman","Revised","DT201","Design","Good","9780465050659"]
  ];
  const insert = db.prepare(`INSERT INTO books
    (owner_id,title,author,edition,course_code,department,condition,isbn,description)
    VALUES(?,?,?,?,?,?,?,?,?)`);
  const tx = db.transaction(rows => rows.forEach((b,i) =>
    insert.run((i % 5) + 1, b[0], b[1], b[2], b[3], b[4], b[5], b[6], "Student-listed textbook available for campus exchange.")
  ));
  tx(books);
}
console.log("Seed complete. Demo users:", db.prepare("SELECT id,name,email FROM users").all());
db.close();