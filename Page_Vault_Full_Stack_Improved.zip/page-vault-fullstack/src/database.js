'use strict';

const Database = require('better-sqlite3');

const seed = [
  ['Project Gutenberg','https://www.gutenberg.org','Books and reading','Free public-domain ebooks.','ebooks, literature, classics'],
  ['Open Library','https://openlibrary.org','Books and reading','Discover books and borrow eligible digital editions.','books, borrowing, catalog'],
  ['Internet Archive','https://archive.org','Books and reading','A digital archive of books, media and historical web pages.','archive, books, media'],
  ['Wikisource','https://wikisource.org','Books and reading','A free library of source texts and historical documents.','texts, history, open'],
  ['HathiTrust','https://www.hathitrust.org','Books and reading','A large shared digital library from academic institutions.','academic, books, library'],
  ['National Digital Library of India','https://ndl.iitkgp.ac.in','National and public libraries','Search learning resources from Indian institutions.','India, learning, books'],
  ['Digital Public Library of America','https://dp.la','National and public libraries','Explore digital collections from libraries and museums.','collections, museums, archives'],
  ['Europeana','https://www.europeana.eu','National and public libraries','Discover digitised cultural heritage from Europe.','culture, heritage, archives'],
  ['Library of Congress','https://www.loc.gov/collections','National and public libraries','Explore books, maps, photographs and manuscripts.','maps, photos, manuscripts'],
  ['NPTEL','https://nptel.ac.in','Courses and textbooks','IIT and IISc online courses, lectures and learning material.','IIT, engineering, courses'],
  ['SWAYAM','https://swayam.gov.in','Courses and textbooks','Online courses from Indian institutions.','India, online courses'],
  ['MIT OpenCourseWare','https://ocw.mit.edu','Courses and textbooks','Free course materials from the Massachusetts Institute of Technology.','MIT, lectures, notes'],
  ['OpenStax','https://openstax.org','Courses and textbooks','Free, peer-reviewed and openly licensed textbooks.','textbooks, science, maths'],
  ['Khan Academy','https://www.khanacademy.org','Courses and textbooks','Lessons and practice across school and college subjects.','practice, learning, maths'],
  ['Shodhganga','https://shodhganga.inflibnet.ac.in','Research and papers','Indian theses and dissertations repository.','India, thesis, dissertation'],
  ['arXiv','https://arxiv.org','Research and papers','Open research papers in science, computing and mathematics.','research, computer science, physics'],
  ['DOAJ','https://doaj.org','Research and papers','Directory of quality open-access journals.','journals, open access'],
  ['Directory of Open Access Books','https://www.doabooks.org','Research and papers','Peer-reviewed academic books available through open access.','academic, books, research']
];

function openDatabase(file = ':memory:') {
  const db = new Database(file);
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');
  db.exec(`
    CREATE TABLE IF NOT EXISTS resources (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      url TEXT NOT NULL,
      category TEXT NOT NULL,
      description TEXT NOT NULL,
      tags TEXT DEFAULT '',
      views INTEGER NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'approved' CHECK(status IN ('approved','pending')),
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE INDEX IF NOT EXISTS idx_resources_status_category ON resources(status, category);
    CREATE INDEX IF NOT EXISTS idx_resources_name ON resources(name);
  `);
  const count = db.prepare('SELECT COUNT(*) AS count FROM resources').get().count;
  if (count === 0) {
    const insert = db.prepare('INSERT INTO resources(name,url,category,description,tags) VALUES(?,?,?,?,?)');
    const transaction = db.transaction(() => seed.forEach(item => insert.run(...item)));
    transaction();
  }
  return db;
}

module.exports = { openDatabase };
