# Page Vault — Full-Stack Edition

Page Vault is a responsive digital-resource directory for books, public libraries, courses, textbooks and research archives. This version upgrades the original static HTML page into a full-stack application.

## Features

- Responsive interface with accessible navigation and light/dark theme.
- Search across resource names, descriptions, categories and tags.
- Category filters, sorting, pagination and saved resources.
- SQLite persistence, seeded starter catalogue and resource view counts.
- Public resource suggestions stored as `pending` for moderation.
- Admin endpoints to review, approve and delete submissions.
- Input validation, parameterized SQL, Helmet security headers and API rate limiting.
- Automated API tests using Node's test runner and Supertest.

## Requirements

- Node.js 20 or newer
- npm

## Run locally

```bash
npm install
cp .env.example .env
npm start
```

Open http://localhost:3000.

On Windows PowerShell, copy the environment template with:

```powershell
Copy-Item .env.example .env
```

The database is created automatically at `./data/page-vault.db` and seeded on first run.

## Run tests

```bash
npm test
```

## Admin moderation

Set a long random `ADMIN_KEY` in `.env`, restart the server, then use the endpoints below. Do not share the key or commit `.env`.

```bash
curl -H "x-admin-key: YOUR_ADMIN_KEY" http://localhost:3000/api/admin/pending
curl -X PATCH -H "x-admin-key: YOUR_ADMIN_KEY" http://localhost:3000/api/admin/resources/19/approve
curl -X DELETE -H "x-admin-key: YOUR_ADMIN_KEY" http://localhost:3000/api/admin/resources/19
```

Replace `19` with the actual resource ID. Admin routes return `403` if a valid key is not configured.

## API overview

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/health` | Health check |
| GET | `/api/stats` | Resource and category totals |
| GET | `/api/resources?q=&category=&sort=&page=&limit=` | Search and list approved resources |
| POST | `/api/resources/:id/view` | Increment a resource view |
| POST | `/api/suggestions` | Submit a resource for moderation |
| GET | `/api/admin/pending` | List pending suggestions (admin) |
| PATCH | `/api/admin/resources/:id/approve` | Approve a suggestion (admin) |
| DELETE | `/api/admin/resources/:id` | Delete a resource (admin) |

## Project structure

```text
page-vault-fullstack/
├── public/
│   ├── index.html
│   ├── styles.css
│   └── app.js
├── src/
│   └── database.js
├── tests/
│   └── api.test.js
├── data/                 # created automatically; database is not committed
├── server.js
├── package.json
├── .env.example
└── README.md
```

## Design and security notes

- User-provided text is rendered with DOM `textContent`, not injected as HTML.
- URLs are validated to allow only HTTP and HTTPS.
- SQL statements use placeholders rather than string-concatenated user input.
- Request bodies are size-limited and API routes are rate-limited.
- Security headers are supplied by Helmet.
- Public suggestions are not immediately published; moderation is required.

## Honest project evaluation note

This implementation addresses the main gaps highlighted by the supplied evaluation rubric: persistent database storage, stronger architecture, validation, error handling and automated tests. A score above 90% cannot be guaranteed; the final score depends on running the project, demonstrating the features, test results and the evaluator's rubric. Before submission, run the app and tests and be ready to explain each module.
