'use strict';

const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const path = require('node:path');
const fs = require('node:fs');
const { openDatabase } = require('./src/database');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const DB_FILE = process.env.DATABASE_FILE || './data/page-vault.db';
const ADMIN_KEY = process.env.ADMIN_KEY || '';

app.disable('x-powered-by');
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com", "data:"],
      scriptSrc: ["'self'"],
      imgSrc: ["'self'", "data:", "https:"],
      connectSrc: ["'self'"]
    }
  }
}));
app.use(express.json({ limit: '20kb' }));
app.use('/api', rateLimit({ windowMs: 15 *  60 * 1000, limit: 180, standardHeaders: 'draft-7', legacyHeaders: false }));

const dbDir = path.dirname(path.resolve(DB_FILE));
fs.mkdirSync(dbDir, { recursive: true });
const db = openDatabase(DB_FILE);

function cleanText(value, max = 160) {
  return typeof value === 'string' ? value.trim().replace(/\s+/g, ' ').slice(0, max) : '';
}
function validHttpUrl(value) {
  try {
    const u = new URL(value);
    return ['http:', 'https:'].includes(u.protocol);
  } catch { return false; }
}
function requireAdmin(req, res, next) {
  if (!ADMIN_KEY || req.get('x-admin-key') !== ADMIN_KEY) {
    return res.status(403).json({ error: 'Admin access is not configured or the key is invalid.' });
  }
  next();
}

app.get('/api/health', (_req, res) => res.json({ status: 'ok' }));

app.get('/api/stats', (_req, res) => {
  const total = db.prepare('SELECT COUNT(*) AS count FROM resources WHERE status = ?').get('approved').count;
  const categories = db.prepare('SELECT category, COUNT(*) AS count FROM resources WHERE status = ? GROUP BY category ORDER BY category').all('approved');
  res.json({ total, categories });
});

app.get('/api/resources', (req, res) => {
  const q = cleanText(req.query.q, 100);
  const category = cleanText(req.query.category, 60);
  const sort = ['name', 'newest', 'popular'].includes(req.query.sort) ? req.query.sort : 'name';
  const page = Math.max(1, Math.min(1000, Number.parseInt(req.query.page, 10) || 1));
  const limit = Math.max(1, Math.min(30, Number.parseInt(req.query.limit, 10) || 9));
  const where = ["status = 'approved'"];
  const params = [];
  if (q) {
    where.push('(name LIKE ? OR description LIKE ? OR category LIKE ? OR tags LIKE ?)');
    const term = `%${q}%`;
    params.push(term, term, term, term);
  }
  if (category && category !== 'All') { where.push('category = ?'); params.push(category); }
  const order = sort === 'newest' ? 'created_at DESC' : sort === 'popular' ? 'views DESC, name COLLATE NOCASE' : 'name COLLATE NOCASE';
  const clause = where.join(' AND ');
  const total = db.prepare(`SELECT COUNT(*) AS count FROM resources WHERE ${clause}`).get(...params).count;
  const rows = db.prepare(`SELECT id, name, url, category, description, tags, views, created_at FROM resources WHERE ${clause} ORDER BY ${order} LIMIT ? OFFSET ?`)
    .all(...params, limit, (page - 1) * limit)
    .map(r => ({ ...r, tags: r.tags ? r.tags.split(',') : [] }));
  res.json({ items: rows, page, limit, total, pages: Math.ceil(total / limit) });
});

app.post('/api/resources/:id/view', (req, res) => {
  const id = Number.parseInt(req.params.id, 10);
  if (!Number.isInteger(id) || id < 1) return res.status(400).json({ error: 'Invalid resource ID.' });
  const result = db.prepare("UPDATE resources SET views = views + 1 WHERE id = ? AND status = 'approved'").run(id);
  if (!result.changes) return res.status(404).json({ error: 'Resource not found.' });
  res.json({ ok: true });
});

// Public submissions are stored as pending until reviewed by an administrator.
app.post('/api/suggestions', (req, res) => {
  const name = cleanText(req.body?.name, 100);
  const url = cleanText(req.body?.url, 500);
  const category = cleanText(req.body?.category, 60);
  const description = cleanText(req.body?.description, 240);
  const tags = cleanText(req.body?.tags, 160);
  const allowed = ['Books and reading', 'National and public libraries', 'Courses and textbooks', 'Research and papers', 'Other'];
  if (name.length < 2 || !validHttpUrl(url) || !allowed.includes(category) || description.length < 10) {
    return res.status(400).json({ error: 'Enter a valid name, HTTPS/HTTP URL, category and description (at least 10 characters).' });
  }
  const result = db.prepare(`INSERT INTO resources (name,url,category,description,tags,status)
    VALUES (?,?,?,?,?,'pending')`).run(name, url, category, description, tags);
  res.status(201).json({ message: 'Suggestion received for review.', id: result.lastInsertRowid });
});

app.get('/api/admin/pending', requireAdmin, (_req, res) => {
  const items = db.prepare("SELECT id,name,url,category,description,tags,created_at FROM resources WHERE status='pending' ORDER BY created_at DESC").all();
  res.json({ items });
});
app.patch('/api/admin/resources/:id/approve', requireAdmin, (req, res) => {
  const id = Number.parseInt(req.params.id, 10);
  if (!Number.isInteger(id) || id < 1) return res.status(400).json({ error: 'Invalid resource ID.' });
  const result = db.prepare("UPDATE resources SET status='approved' WHERE id=? AND status='pending'").run(id);
  if (!result.changes) return res.status(404).json({ error: 'Pending suggestion not found.' });
  res.json({ ok: true });
});
app.delete('/api/admin/resources/:id', requireAdmin, (req, res) => {
  const id = Number.parseInt(req.params.id, 10);
  if (!Number.isInteger(id) || id < 1) return res.status(400).json({ error: 'Invalid resource ID.' });
  const result = db.prepare('DELETE FROM resources WHERE id=?').run(id);
  if (!result.changes) return res.status(404).json({ error: 'Resource not found.' });
  res.json({ ok: true });
});

app.use(express.static(path.join(__dirname, 'public')));
app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: 'An unexpected server error occurred.' });
});

if (require.main === module) {
  app.listen(PORT, () => console.log(`Page Vault running at http://localhost:${PORT}`));
}
module.exports = { app, db };
