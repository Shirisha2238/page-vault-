'use strict';

const state = { category: 'All', query: '', sort: 'name', page: 1, savedOnly: false, saved: new Set(JSON.parse(localStorage.getItem('pageVaultSaved') || '[]')), pages: 1 };
const grid = document.querySelector('#resourceGrid');
const template = document.querySelector('#resourceTemplate');
const search = document.querySelector('#searchInput');
const resultsCount = document.querySelector('#resultsCount');
const pagination = document.querySelector('#pagination');
const categoryFilters = document.querySelector('#categoryFilters');
const savedCount = document.querySelector('#savedCount');

const escapeText = value => String(value ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));

function saveState() {
  localStorage.setItem('pageVaultSaved', JSON.stringify([...state.saved]));
  savedCount.textContent = state.saved.size;
}
function updateFilters() {
  categoryFilters.querySelectorAll('button').forEach(btn => {
    const active = btn.dataset.category === state.category;
    btn.classList.toggle('active', active);
    btn.setAttribute('aria-pressed', String(active));
  });
  document.querySelector('#savedToggle').setAttribute('aria-pressed', String(state.savedOnly));
}
function renderCard(resource) {
  const node = template.content.firstElementChild.cloneNode(true);
  node.querySelector('.category-label').textContent = resource.category;
  node.querySelector('.resource-name').textContent = resource.name;
  node.querySelector('.resource-description').textContent = resource.description;
  node.querySelector('.views').textContent = `${resource.views} views`;
  const link = node.querySelector('.visit-link');
  link.href = resource.url;
  link.addEventListener('click', () => {
    fetch(`/api/resources/${resource.id}/view`, { method: 'POST' }).catch(() => {});
  });
  const tags = node.querySelector('.tag-list');
  resource.tags.slice(0, 3).forEach(tag => {
    const span = document.createElement('span');
    span.className = 'tag'; span.textContent = tag; tags.append(span);
  });
  const save = node.querySelector('.save-button');
  const isSaved = state.saved.has(resource.id);
  save.classList.toggle('saved', isSaved);
  save.textContent = isSaved ? '♥' : '♡';
  save.setAttribute('aria-label', isSaved ? `Remove ${resource.name} from saved resources` : `Save ${resource.name}`);
  save.addEventListener('click', () => {
    state.saved.has(resource.id) ? state.saved.delete(resource.id) : state.saved.add(resource.id);
    saveState(); loadResources();
  });
  return node;
}
function renderPagination(page, pages) {
  pagination.replaceChildren();
  if (pages <= 1) return;
  const add = (label, target, disabled = false, active = false) => {
    const button = document.createElement('button');
    button.className = `page-button${active ? ' active' : ''}`;
    button.textContent = label; button.disabled = disabled;
    button.setAttribute('aria-label', label === '‹' ? 'Previous page' : label === '›' ? 'Next page' : `Page ${label}`);
    button.addEventListener('click', () => { state.page = target; loadResources(); document.querySelector('#library').scrollIntoView({behavior:'smooth'}); });
    pagination.append(button);
  };
  add('‹', page - 1, page === 1);
  for (let p = 1; p <= pages; p++) add(String(p), p, false, p === page);
  add('›', page + 1, page === pages);
}
async function loadResources() {
  updateFilters();
  grid.replaceChildren();
  const params = new URLSearchParams({ q: state.query, category: state.category, sort: state.sort, page: state.page, limit: 9 });
  try {
    const response = await fetch(`/api/resources?${params}`);
    if (!response.ok) throw new Error('Could not load resources.');
    const data = await response.json();
    let items = data.items;
    if (state.savedOnly) items = items.filter(item => state.saved.has(item.id));
    resultsCount.textContent = `${items.length} ${items.length === 1 ? 'resource' : 'resources'} shown${state.savedOnly ? ' · saved' : ''}`;
    if (!items.length) {
      const empty = document.createElement('div'); empty.className = 'empty-state';
      empty.textContent = state.savedOnly ? 'No saved resources yet. Use the heart on a resource to save it.' : 'No matching resources. Try another search or clear your filters.';
      grid.append(empty);
    } else items.forEach(item => grid.append(renderCard(item)));
    state.pages = data.pages;
    renderPagination(state.page, data.pages);
  } catch (error) {
    const message = document.createElement('div'); message.className = 'empty-state';
    message.textContent = 'The library could not be loaded. Check that the server is running, then refresh the page.';
    grid.append(message); resultsCount.textContent = 'Connection error'; pagination.replaceChildren();
  }
}
async function loadStats() {
  try {
    const response = await fetch('/api/stats');
    const data = await response.json();
    document.querySelector('#totalCount').textContent = data.total;
    document.querySelector('#categoryCount').textContent = data.categories.length;
  } catch { document.querySelector('#totalCount').textContent = '—'; }
}
let searchTimer;
search.addEventListener('input', () => {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(() => { state.query = search.value.trim(); state.page = 1; state.savedOnly = false; loadResources(); }, 220);
});
categoryFilters.addEventListener('click', event => {
  const button = event.target.closest('button[data-category]');
  if (!button) return;
  state.category = button.dataset.category; state.page = 1; state.savedOnly = false; loadResources();
});
document.querySelector('#sortSelect').addEventListener('change', event => { state.sort = event.target.value; state.page = 1; loadResources(); });
document.querySelector('#savedToggle').addEventListener('click', () => { state.savedOnly = !state.savedOnly; state.page = 1; loadResources(); });
document.querySelector('#clearFilters').addEventListener('click', () => {
  state.category = 'All'; state.query = ''; state.sort = 'name'; state.page = 1; state.savedOnly = false;
  search.value = ''; document.querySelector('#sortSelect').value = 'name'; loadResources();
});
document.querySelector('#suggestForm').addEventListener('submit', async event => {
  event.preventDefault();
  const form = event.currentTarget;
  const message = document.querySelector('#formMessage');
  const payload = Object.fromEntries(new FormData(form).entries());
  message.textContent = 'Sending…';
  try {
    const response = await fetch('/api/suggestions', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(payload) });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || 'Submission failed.');
    message.textContent = 'Thank you! Your suggestion has been sent for review.';
    form.reset();
  } catch (error) { message.textContent = error.message; }
});
document.querySelector('#themeToggle').addEventListener('click', () => {
  document.body.classList.toggle('dark');
  localStorage.setItem('pageVaultTheme', document.body.classList.contains('dark') ? 'dark' : 'light');
});
if (localStorage.getItem('pageVaultTheme') === 'dark') document.body.classList.add('dark');
document.addEventListener('keydown', event => {
  if (event.key === '/' && !['INPUT','TEXTAREA','SELECT'].includes(document.activeElement.tagName)) {
    event.preventDefault(); search.focus();
  }
});
document.querySelector('#year').textContent = new Date().getFullYear();
saveState(); loadStats(); loadResources();
