'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const request = require('supertest');
const { app, db } = require('../server');

test('health endpoint reports server status', async () => {
  const response = await request(app).get('/api/health');
  assert.equal(response.status, 200);
  assert.equal(response.body.status, 'ok');
});

test('resources endpoint returns seeded catalogue with pagination', async () => {
  const response = await request(app).get('/api/resources?limit=5&page=1');
  assert.equal(response.status, 200);
  assert.equal(response.body.items.length, 5);
  assert.ok(response.body.total >= 18);
  assert.equal(response.body.pages, Math.ceil(response.body.total / 5));
});

test('search filters resources by topic', async () => {
  const response = await request(app).get('/api/resources?q=IIT');
  assert.equal(response.status, 200);
  assert.ok(response.body.items.some(item => item.name === 'NPTEL'));
});

test('invalid suggestion is rejected', async () => {
  const response = await request(app).post('/api/suggestions').send({
    name: 'x', url: 'javascript:alert(1)', category: 'Other', description: 'too short'
  });
  assert.equal(response.status, 400);
});

test('valid suggestion is stored pending moderation', async () => {
  const response = await request(app).post('/api/suggestions').send({
    name: 'Example Learning Hub', url: 'https://example.org',
    category: 'Other', description: 'A useful learning resource for students.', tags: 'learning'
  });
  assert.equal(response.status, 201);
  const row = db.prepare('SELECT status FROM resources WHERE id=?').get(response.body.id);
  assert.equal(row.status, 'pending');
});

test('admin moderation is protected without an admin key', async () => {
  const response = await request(app).get('/api/admin/pending');
  assert.equal(response.status, 403);
});
